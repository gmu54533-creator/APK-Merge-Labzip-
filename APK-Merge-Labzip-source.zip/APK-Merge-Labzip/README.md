# APK-Merge-Labzip

A defensive Android APK inspection and authorized rebuild toolkit for Kali Linux and ARM64 Termux.

> This project does **not** inject payloads, add covert remote access, bypass Android protections, or modify apps without authorization. It is intended for APKs you own or are authorized to assess.

## Features

- APK metadata, package name, SDK levels and permission inspection (`aapt2`)
- APK signature verification (`apksigner`)
- SHA-256 checksum and native ABI inventory
- Optional Apktool decode and rebuild workflow
- ZIP alignment and signing of rebuilt APKs
- Clear dependency checks and actionable error messages

## Requirements

- Python 3.10+
- Java 17+ (required by Apktool and Android build tools)
- Android build tools: `aapt2`, `zipalign`, `apksigner`
- `apktool` (required only for decode/rebuild)
- `unzip` (used for archive inventory)

The commands must be available on your `PATH`.

## Kali Linux

```bash
sudo apt update
sudo apt install -y python3 python3-venv default-jdk unzip zip
```

Install Apktool and Android SDK Build Tools using their official documentation, then ensure `apktool`, `aapt2`, `zipalign`, and `apksigner` are on `PATH`.

```bash
git clone https://github.com/gmu54533-creator/APK-Merge-Labzip-.git
cd APK-Merge-Labzip-
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e .
apklab doctor
```

## Termux (ARM64)

```bash
pkg update && pkg upgrade -y
pkg install -y python git openjdk-17 unzip zip
```

Install the Android utilities from a trusted Termux-compatible source. Some Android SDK host binaries are not compatible with Termux/ARM64; use Termux-native builds where available. Check each command with `command -v`.

```bash
git clone https://github.com/gmu54533-creator/APK-Merge-Labzip-.git
cd APK-Merge-Labzip-
python -m pip install -e .
apklab doctor
```

## Usage

Inspect an APK:

```bash
apklab inspect ./my-owned-app.apk
```

Decode with Apktool:

```bash
apklab decode ./my-owned-app.apk --out ./decoded-app
```

Rebuild an authorized decoded project:

```bash
apklab rebuild ./decoded-app --out ./rebuilt-unsigned.apk
```

Align and sign a rebuilt APK:

```bash
apklab sign ./rebuilt-unsigned.apk \
  --keystore ./release.keystore \
  --alias release \
  --out ./rebuilt-signed.apk
```

Verify a signature:

```bash
apklab verify ./rebuilt-signed.apk
```

Create a keystore (keep it private and out of Git):

```bash
keytool -genkeypair -v -keystore release.keystore \
  -alias release -keyalg RSA -keysize 2048 -validity 10000
```

## Important signing notes

- Re-signing an APK with your own key generally prevents it from updating an installed copy signed by the original developer.
- Never commit `.jks`, `.keystore`, passwords, tokens, or private keys.
- Do not modify an APK after signing it.
- Lowering `minSdkVersion` does not make unsupported APIs compatible.
- Test on devices/emulators you own or are authorized to use.

## Android 14/15 compatibility

Compatibility depends on the app's actual APIs, manifest, runtime permissions, target SDK, native libraries and ABI. This tool reports useful metadata; it cannot automatically make every APK compatible with Android 14 or 15.

## License

MIT. See [LICENSE](LICENSE).
