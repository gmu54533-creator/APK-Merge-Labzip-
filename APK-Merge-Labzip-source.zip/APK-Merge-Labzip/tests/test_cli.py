from apklab.cli import build_parser

def test_parser_has_expected_commands():
    parser = build_parser()
    assert parser.prog == "apklab"
