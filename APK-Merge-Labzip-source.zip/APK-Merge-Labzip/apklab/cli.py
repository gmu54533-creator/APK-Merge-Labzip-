"""Command-line interface for defensive APK inspection and authorized rebuilding."""
from __future__ import annotations

import argparse
import hashlib
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

TOOLS = {
    "java": "Java runtime",
    "aapt2": "Android Asset Packaging Tool 2",
    "apksigner": "Android APK signer",
    "zipalign": "Android ZIP alignment tool",
    "apktool": "Apktool (optional for decode/rebuild)",
    "unzip": "unzip (optional archive listing)",
}


def run(cmd: list[str], *, check: bool = True) -> subprocess.CompletedProcess:
    try:
        p = subprocess.run(cmd, text=True, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT, check=False)
    except FileNotFoundError:
        raise RuntimeError(f"Missing dependency: {cmd[0]} is not on PATH.")
    if check and p.returncode != 0:
        raise RuntimeError(f"Command failed ({p.returncode}): {' '.join(cmd)}\n{p.stdout}")
    return p


def require_file(path: str) -> Path:
    p = Path(path).expanduser().resolve()
    if not p.is_file():
        raise RuntimeError(f"File not found: {p}")
    return p


def doctor(_: argparse.Namespace) -> int:
    missing = []
    for binary, label in TOOLS.items():
        found = shutil.which(binary)
        optional = binary in {"apktool", "unzip"}
        status = f"FOUND: {found}" if found else ("OPTIONAL - not found" if optional else "MISSING")
        print(f"{label}: {status}")
        if not found and not optional:
            missing.append(binary)
    return 1 if missing else 0


def inspect(args: argparse.Namespace) -> int:
    apk = require_file(args.apk)
    print(f"File: {apk}")
    print(f"Size: {apk.stat().st_size} bytes")
    digest = hashlib.sha256(apk.read_bytes()).hexdigest()
    print(f"SHA-256: {digest}")
    print("\n--- APK metadata (aapt2) ---")
    p = run(["aapt2", "dump", "badging", str(apk)], check=False)
    if p.returncode == 0:
        for line in p.stdout.splitlines():
            if line.startswith(("package:", "sdkVersion:", "targetSdkVersion:",
                                 "application-label:", "native-code:")):
                print(line)
    else:
        print(p.stdout)
    print("\n--- Declared permissions ---")
    p = run(["aapt2", "dump", "permissions", str(apk)], check=False)
    print(p.stdout if p.stdout else "(No permission output.)")
    print("\n--- Native libraries / ABI ---")
    try:
        with zipfile.ZipFile(apk) as zf:
            libs = [n for n in zf.namelist() if n.startswith("lib/") and n.endswith(".so")]
            if libs:
                for name in libs:
                    print(name)
            else:
                print("No packaged .so libraries found.")
    except zipfile.BadZipFile:
        raise RuntimeError("Input is not a valid ZIP/APK archive.")
    return 0


def verify(args: argparse.Namespace) -> int:
    apk = require_file(args.apk)
    p = run(["apksigner", "verify", "--verbose", str(apk)], check=False)
    print(p.stdout)
    return p.returncode


def decode(args: argparse.Namespace) -> int:
    apk = require_file(args.apk)
    out = Path(args.out).expanduser().resolve()
    if out.exists():
        raise RuntimeError(f"Output already exists: {out}. Choose a new path.")
    run(["apktool", "d", "-f", str(apk), "-o", str(out)])
    print(f"Decoded project: {out}")
    return 0


def rebuild(args: argparse.Namespace) -> int:
    source = Path(args.project).expanduser().resolve()
    if not source.is_dir():
        raise RuntimeError(f"Decoded project directory not found: {source}")
    out = Path(args.out).expanduser().resolve()
    if out.exists():
        raise RuntimeError(f"Output already exists: {out}")
    run(["apktool", "b", str(source), "-o", str(out)])
    print(f"Unsigned APK created: {out}")
    return 0


def sign(args: argparse.Namespace) -> int:
    apk = require_file(args.apk)
    ks = require_file(args.keystore)
    if not args.alias.strip():
        raise RuntimeError("Keystore alias cannot be empty.")
    out = Path(args.out).expanduser().resolve()
    if out.exists():
        raise RuntimeError(f"Output already exists: {out}")
    aligned = out.with_name(out.stem + ".aligned-unsigned.apk")
    try:
        run(["zipalign", "-p", "-f", "4", str(apk), str(aligned)])
        run(["apksigner", "sign", "--ks", str(ks), "--ks-key-alias",
             args.alias, "--out", str(out), str(aligned)])
        run(["apksigner", "verify", "--verbose", str(out)])
        print(f"Signed and verified APK: {out}")
    finally:
        if aligned.exists():
            aligned.unlink()
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="apklab",
        description="Inspect and rebuild APKs you own or are authorized to modify.")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("doctor", help="Check required and optional dependencies")
    p.set_defaults(func=doctor)

    p = sub.add_parser("inspect", help="Inspect APK metadata, permissions, ABI and hash")
    p.add_argument("apk")
    p.set_defaults(func=inspect)

    p = sub.add_parser("verify", help="Verify APK signature")
    p.add_argument("apk")
    p.set_defaults(func=verify)

    p = sub.add_parser("decode", help="Decode an APK with Apktool")
    p.add_argument("apk")
    p.add_argument("--out", required=True)
    p.set_defaults(func=decode)

    p = sub.add_parser("rebuild", help="Rebuild an authorized Apktool project")
    p.add_argument("project")
    p.add_argument("--out", required=True)
    p.set_defaults(func=rebuild)

    p = sub.add_parser("sign", help="Align, sign and verify a rebuilt APK")
    p.add_argument("apk")
    p.add_argument("--keystore", required=True)
    p.add_argument("--alias", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=sign)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    try:
        code = args.func(args)
    except RuntimeError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        code = 2
    raise SystemExit(code)


if __name__ == "__main__":
    main()
